# Graph Report - mz_admin  (2026-10-07)

## Corpus Check
- 61 files · ~59,044 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 677 nodes · 1253 edges · 48 communities (47 shown, 1 thin omitted)
- Extraction: 90% EXTRACTED · 10% INFERRED · 0% AMBIGUOUS · INFERRED: 126 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `74f385e6`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- app.js
- Per-Context Visual Identity
- client/main.lua
- MZAdminSpectate.Start
- garage_wizard.lua
- client/warnings.lua
- MZAdminSecurity.Authorize
- MZAdminMenu.Open
- world_outlets_wizard.lua
- commands.lua
- Contrato de segurança e menu do `mz_admin`
- staff_management.lua
- Contrato de layout dashboard do `mz_menu`
- world_wizard.lua
- mz_menu
- Q: Como o Player Selector se integra ao mz_menu?
- noclip.lua
- server/wall.lua
- client/security_alerts.lua
- client/wall.lua
- world_furniture_catalog.lua
- Integração em resources MZ
- admin_logs.lua
- Contrato de tema por contexto do `mz_menu`
- Plano de adaptação do painel Staff QBCore
- Contrato dos logs administrativos
- Contrato de interação e movimento do contexto
- Checklist runtime do `mz_admin`
- Contrato do spectate administrativo
- Contrato do wall administrativo
- Implementação da integração BanGuard
- Prontidão da integração com BanGuard
- Q: Onde ficam busca e revalidacao do Player Selector administrativo?
- logs.lua

## God Nodes (most connected - your core abstractions)
1. `MZAdminSecurity.Authorize()` - 21 edges
2. `MZAdminMenu.Open()` - 19 edges
3. `MZAdminSpectate.Start()` - 18 edges
4. `mz_menu` - 15 edges
5. `GetGameTimer()` - 14 edges
6. `cfg()` - 14 edges
7. `awaitCallback()` - 12 edges
8. `MZAdminWall.BuildSnapshot()` - 12 edges
9. `escapeHtml()` - 12 edges
10. `MZMenu.ShowContext()` - 12 edges

## Surprising Connections (you probably didn't know these)
- `Business Resource Ownership` --semantically_similar_to--> `Server-Side Security Boundary`  [INFERRED] [semantically similar]
  docs/INTEGRATION_NOTES.md → README.md
- `Menu Presentation Responsibility` --semantically_similar_to--> `mz_menu Visual Layer`  [INFERRED] [semantically similar]
  docs/INTEGRATION_NOTES.md → README.md
- `MZAdminSpectate.Start()` --calls--> `MZAdminNoClip.IsEnabled()`  [INFERRED]
  mz_admin/server/spectate.lua → mz_admin/server/main.lua
- `trigger()` --calls--> `TriggerClientEvent()`  [INFERRED]
  server/main.lua → mz_admin/tests/server_debug_security_harness.lua
- `Per-Context Visual Identity` --conceptually_related_to--> `Context Panel`  [INFERRED]
  docs/CONTEXT_THEME_CONTRACT.md → web/index.html

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Context Visual Identity Flow** — readme_native_nui_backend, docs_context_theme_contract_context_visual_identity, docs_context_theme_contract_theme_inheritance_chain, web_index_context_panel [INFERRED 0.85]
- **Visual Layer Security Boundary** — readme_server_side_security_boundary, docs_context_theme_contract_visual_metadata_authorization_boundary, docs_integration_notes_business_resource_ownership, docs_integration_notes_menu_presentation_responsibility [INFERRED 0.95]

## Communities (48 total, 1 thin omitted)

### Community 0 - "app.js"
Cohesion: 0.06
Nodes (54): app, applySearchFilter(), backBtn, bindPlayerSelectorResults(), brandEl, cancelPlayerSelector(), closeAll(), closeBtn (+46 more)

### Community 1 - "Per-Context Visual Identity"
Cohesion: 0.11
Nodes (18): Per-Context Visual Identity, Theme Inheritance Chain, Theme Payload Validation, Visual Metadata Authorization Boundary, Business Resource Ownership, Embedded Asset Strategy, Menu Presentation Responsibility, Combat Input Suppression (+10 more)

### Community 2 - "client/main.lua"
Cohesion: 0.09
Nodes (63): actualMovementEnabled(), alertReady(), applyMovementInput(), awaitNui(), beginNuiDialog(), cfg(), chat(), contextReady() (+55 more)

### Community 3 - "MZAdminSpectate.Start"
Cohesion: 0.10
Nodes (30): getClosestVehicle(), getGroundCoordsForEntity(), applyHiddenState(), notify(), restorePedState(), stopLocal(), updateTarget(), validCoords() (+22 more)

### Community 4 - "garage_wizard.lua"
Cohesion: 0.13
Nodes (38): awaitCallback(), MZAdminClient.Authorize(), MZAdminClient.CreateManagedGarage(), MZAdminClient.GetMenuContext(), MZAdminClient.ListAdminLogs(), MZAdminClient.ListGarageOrganizations(), MZAdminClient.ListManagedGarages(), MZAdminClient.ListOnlinePlayers() (+30 more)

### Community 5 - "client/warnings.lua"
Cohesion: 0.16
Nodes (29): MZAdminClient.StaffRequest(), bind(), cloneFilters(), errorMessage(), formatUnixUtc(), MZAdminBans.Configure(), MZAdminBans.Open(), MZAdminBans.PromptCreate() (+21 more)

### Community 6 - "MZAdminSecurity.Authorize"
Cohesion: 0.07
Nodes (46): auditResult(), banGuardCall(), MZAdminBansServer.Create(), MZAdminBansServer.Get(), MZAdminBansServer.List(), MZAdminBansServer.Revoke(), response(), auditTargetAction() (+38 more)

### Community 7 - "MZAdminMenu.Open"
Cohesion: 0.13
Nodes (28): MZAdminGarageWizard.GetMenuId(), action(), execute(), input(), kickAction(), MZAdminMenu.Open(), openOnlinePlayers(), option() (+20 more)

### Community 8 - "world_outlets_wizard.lua"
Cohesion: 0.14
Nodes (25): MZAdminFurniture.GetMenuId(), MZAdminFurniture.Register(), bind(), closePending(), MZAdminChargingOutlets.GetMenuId(), MZAdminChargingOutlets.Register(), notify(), openList() (+17 more)

### Community 9 - "commands.lua"
Cohesion: 0.13
Nodes (18): applyMaxPerformance(), applyRandomVisualTuning(), authorize(), blockNativeWeaponCommand(), deleteVehicle(), fullRandomTune(), getWeaponHashFromInput(), giveTestWeapon() (+10 more)

### Community 10 - "Contrato de segurança e menu do `mz_admin`"
Cohesion: 0.11
Nodes (18): Autoridade, Ação local, Ação sobre outro player, Banimentos, Compatibilidade, Contrato de segurança e menu do `mz_admin`, Criacao de garagens, Diretório de players (+10 more)

### Community 11 - "staff_management.lua"
Cohesion: 0.33
Nodes (16): assignmentDetails(), assignRole(), bind(), createRole(), editRole(), input(), MZAdminStaffManagement.Register(), notify() (+8 more)

### Community 16 - "Contrato de layout dashboard do `mz_menu`"
Cohesion: 0.25
Nodes (7): Busca, Campos de contexto, Campos de opcao, Compatibilidade, Contrato de layout dashboard do `mz_menu`, Objetivo, Seguranca

### Community 17 - "world_wizard.lua"
Cohesion: 0.32
Nodes (15): averageInteraction(), bind(), buildAccessPolicy(), configureDraft(), createGroup(), fetchGroups(), groupPolicyLabel(), MZAdminWorld.ShowDraft() (+7 more)

### Community 18 - "mz_menu"
Cohesion: 0.12
Nodes (16): Alert / Confirm, Backend, Exports client-side, Exports server-side, Ideia, Input, Layout dashboard (0.4.0-test), Layout v0 convertido (+8 more)

### Community 20 - "Q: Como o Player Selector se integra ao mz_menu?"
Cohesion: 0.40
Nodes (4): Answer, Outcome, Q: Como o Player Selector se integra ao mz_menu?, Source Nodes

### Community 21 - "noclip.lua"
Cohesion: 0.22
Nodes (11): applyNoClipState(), stopNoClip(), toggleNoClipAuthorized(), getNoClipEntity(), MZNoClip.stop(), MZNoClip.toggle(), notify(), restoreEntity() (+3 more)

### Community 22 - "server/wall.lua"
Cohesion: 0.33
Nodes (13): actorPayload(), audit(), citizenId(), filteredSnapshot(), MZAdminWall.BuildSnapshot(), MZAdminWall.IsEnabled(), MZAdminWall.Tick(), normalizeSource() (+5 more)

### Community 23 - "client/security_alerts.lua"
Cohesion: 0.36
Nodes (10): bind(), detailMenuId(), evidenceMetadata(), incidentMetadata(), MZAdminSecurityAlerts.OpenList(), MZAdminSecurityAlerts.Register(), notify(), openDetails() (+2 more)

### Community 24 - "client/wall.lua"
Cohesion: 0.27
Nodes (7): cleanText(), cleanupWall(), MZAdminWallClient.SetState(), notify(), setting(), toggleWall(), vehicleLabel()

### Community 25 - "world_furniture_catalog.lua"
Cohesion: 0.42
Nodes (10): bind(), callback(), money(), notify(), openCatalog(), reconcilePlayer(), request(), runRecovery() (+2 more)

### Community 26 - "Integração em resources MZ"
Cohesion: 0.20
Nodes (9): Integração em resources MZ, Interacao e movimento do contexto, NUI própria, Não fazer, Ordem no server.cfg, Padrão recomendado, Sobre virar uma lib maior, Versão 0.3.0 - NUI própria estilo v0 (+1 more)

### Community 27 - "admin_logs.lua"
Cohesion: 0.47
Nodes (8): bind(), cloneFilters(), displayDate(), hasFilters(), itemMetadata(), MZAdminLogs.Open(), requestFilters(), trim()

### Community 28 - "Contrato de tema por contexto do `mz_menu`"
Cohesion: 0.22
Nodes (8): Ciclo de vida, Compatibilidade, Contrato de tema por contexto do `mz_menu`, Escopo, Limite de responsabilidade, Payload, Resolucao e heranca, Teste manual

### Community 29 - "Plano de adaptação do painel Staff QBCore"
Cohesion: 0.22
Nodes (8): Adaptação concluída: advertências, Lote de garagens aplicado, Matriz, Plano de adaptação do painel Staff QBCore, Primeiro lote aplicado, Princípios da adaptação, Próxima ordem, Referência analisada

### Community 30 - "Contrato dos logs administrativos"
Cohesion: 0.25
Nodes (7): Autorização, Compatibilidade do `mz_org`, Contrato dos logs administrativos, DTO, Escopo, Filtros, Responsabilidades

### Community 31 - "Contrato de interação e movimento do contexto"
Cohesion: 0.25
Nodes (7): Configuração, Contrato de interação e movimento do contexto, Exports de movimento, Objetivo, Posicionamento de garagens, Regras, Teste runtime

### Community 32 - "Checklist runtime do `mz_admin`"
Cohesion: 0.25
Nodes (7): Advertências (`mz_warns`), Checklist runtime do `mz_admin`, Evidência, Interface e regressão, Negativos obrigatórios, Positivos por permissão, Preparação

### Community 33 - "Contrato do spectate administrativo"
Cohesion: 0.25
Nodes (7): Auditoria, Autoridade, Contrato do spectate administrativo, Estado local, Estado oficial, Lifecycle, Limites

### Community 34 - "Contrato do wall administrativo"
Cohesion: 0.25
Nodes (7): Auditoria, Autoridade, Configuração segura, Contrato do wall administrativo, Dados, Estado e revalidação, Fora do escopo

### Community 36 - "Implementação da integração BanGuard"
Cohesion: 0.29
Nodes (6): Comandos estáticos, Entrega local, Implementação da integração BanGuard, Runtime pendente, Segurança, Validação estática executada

### Community 37 - "Prontidão da integração com BanGuard"
Cohesion: 0.33
Nodes (5): Ações proibidas, Bloqueio runtime real, Estado atual, Integração aplicada, Prontidão da integração com BanGuard

### Community 38 - "Q: Onde ficam busca e revalidacao do Player Selector administrativo?"
Cohesion: 0.40
Nodes (4): Answer, Outcome, Q: Onde ficam busca e revalidacao do Player Selector administrativo?, Source Nodes

## Knowledge Gaps
- **132 isolated node(s):** `app`, `contextPanel`, `menuTitle`, `brandEl`, `menuSubtitle` (+127 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **1 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `MZAdminClient.NotifyDenied()` connect `garage_wizard.lua` to `client/wall.lua`, `noclip.lua`?**
  _High betweenness centrality (0.139) - this node is a cross-community bridge._
- **Why does `MZAdminMenu.Open()` connect `MZAdminMenu.Open` to `garage_wizard.lua`, `client/warnings.lua`, `world_outlets_wizard.lua`, `staff_management.lua`, `client/security_alerts.lua`?**
  _High betweenness centrality (0.126) - this node is a cross-community bridge._
- **Why does `toggleNoClipAuthorized()` connect `noclip.lua` to `client/main.lua`, `garage_wizard.lua`?**
  _High betweenness centrality (0.121) - this node is a cross-community bridge._
- **Are the 14 inferred relationships involving `MZAdminSecurity.Authorize()` (e.g. with `MZAdminBansServer.Create()` and `MZAdminBansServer.Get()`) actually correct?**
  _`MZAdminSecurity.Authorize()` has 14 INFERRED edges - model-reasoned connections that need verification._
- **Are the 13 inferred relationships involving `MZAdminMenu.Open()` (e.g. with `MZAdminClient.GetMenuContext()` and `MZAdminBans.Configure()`) actually correct?**
  _`MZAdminMenu.Open()` has 13 INFERRED edges - model-reasoned connections that need verification._
- **Are the 7 inferred relationships involving `MZAdminSpectate.Start()` (e.g. with `MZAdminNoClip.IsEnabled()` and `MZAdminSecurity.Authorize()`) actually correct?**
  _`MZAdminSpectate.Start()` has 7 INFERRED edges - model-reasoned connections that need verification._
- **Are the 13 inferred relationships involving `GetGameTimer()` (e.g. with `deleteVehicle()` and `loadModel()`) actually correct?**
  _`GetGameTimer()` has 13 INFERRED edges - model-reasoned connections that need verification._