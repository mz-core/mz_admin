# Graph Report - mz_admin  (2026-09-10)

## Corpus Check
- Corpus is ~48,060 words - fits in a single context window. You may not need a graph.

## Summary
- 402 nodes · 814 edges · 32 communities (31 shown, 1 thin omitted)
- Extraction: 86% EXTRACTED · 14% INFERRED · 0% AMBIGUOUS · INFERRED: 111 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Documentation and Contracts
- Security and Moderation Adapters
- Spectate Server and Harness
- Garage UI Wizard
- World Props and Furniture UI
- Admin Client Commands
- Admin Menu Routing
- Staff Management UI
- Door Management UI
- Ban Management UI
- Noclip Runtime
- Warning Management UI
- Wall Server Observability
- Client Server Adapter
- Security Alert UI
- Player Action Orchestration
- Wall Client Rendering
- Whitelist UI
- Admin Logs UI
- Spectate Client Runtime
- Log Filter Adapter

## God Nodes (most connected - your core abstractions)
1. `MZAdminSecurity.Authorize()` - 20 edges
2. `MZAdminMenu.Open()` - 19 edges
3. `MZAdminSpectate.Start()` - 18 edges
4. `MZAdminWall.BuildSnapshot()` - 12 edges
5. `awaitCallback()` - 11 edges
6. `MZAdminClient.StaffRequest()` - 11 edges
7. `GetGameTimer()` - 11 edges
8. `MZAdminSpectate.Tick()` - 10 edges
9. `MZAdminWall.Tick()` - 10 edges
10. `startPlacement()` - 9 edges

## Surprising Connections (you probably didn't know these)
- `MZAdminWall.BuildSnapshot()` --calls--> `GetPlayers()`  [INFERRED]
  server/wall.lua → tests/security_contract_harness.lua
- `getGroundCoordsForEntity()` --calls--> `GetEntityCoords()`  [INFERRED]
  client/commands.lua → tests/security_contract_harness.lua
- `getClosestVehicle()` --calls--> `GetEntityCoords()`  [INFERRED]
  client/commands.lua → tests/security_contract_harness.lua
- `coordinate()` --calls--> `GetEntityCoords()`  [INFERRED]
  client/garage_wizard.lua → tests/security_contract_harness.lua
- `coordinate()` --calls--> `GetEntityHeading()`  [INFERRED]
  client/garage_wizard.lua → tests/security_contract_harness.lua

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Controle administrativo fail-closed** — mz_admin_readme_fail_closed_authorization, mz_admin_docs_admin_logs_contract_double_authorization, mz_admin_docs_security_and_menu_contract_server_side_revalidation, mz_admin_docs_banguard_integration_readiness_is_ready_gate [INFERRED 0.95]
- **Contratos de observabilidade Staff** — mz_admin_docs_admin_logs_contract_admin_logs_contract, mz_admin_docs_spectate_contract_spectate_contract, mz_admin_docs_wall_contract_wall_contract [EXTRACTED 1.00]
- **Autoridade delegada por domínio** — mz_admin_readme_banguard_delegation, mz_admin_docs_qbcore_staff_panel_adaptation_plan_managed_garage_delegation, mz_admin_docs_security_and_menu_contract_resource_domain_delegation [INFERRED 0.95]

## Communities (32 total, 1 thin omitted)

### Community 0 - "Documentation and Contracts"
Cohesion: 0.06
Nodes (43): Contrato dos logs administrativos, Dupla validação de logs administrativos, mz_core:ListGlobalLogsSecure, Isolamento entre logs globais e organizacionais, DTO sanitizado de logs globais, Implementação da integração BanGuard, API protegida do BanGuard, Validação runtime pendente do BanGuard (+35 more)

### Community 1 - "Security and Moderation Adapters"
Cohesion: 0.13
Nodes (26): auditResult(), banGuardCall(), MZAdminBansServer.Create(), MZAdminBansServer.Get(), MZAdminBansServer.List(), MZAdminBansServer.Revoke(), response(), authorize() (+18 more)

### Community 2 - "Spectate Server and Harness"
Cohesion: 0.14
Nodes (24): audit(), deny(), entityPayload(), hierarchyMessage(), MZAdminSpectate.IsActive(), MZAdminSpectate.Start(), MZAdminSpectate.Stop(), MZAdminSpectate.Tick() (+16 more)

### Community 3 - "Garage UI Wizard"
Cohesion: 0.21
Nodes (25): binding(), capturePoint(), changeManagedState(), confirmOverwrite(), coordinate(), draftLabel(), draftPayload(), editManagedGarage() (+17 more)

### Community 4 - "World Props and Furniture UI"
Cohesion: 0.16
Nodes (23): bind(), callback(), money(), MZAdminFurniture.GetMenuId(), MZAdminFurniture.Register(), notify(), openCatalog(), reconcilePlayer() (+15 more)

### Community 5 - "Admin Client Commands"
Cohesion: 0.13
Nodes (14): authorize(), blockNativeWeaponCommand(), deleteVehicle(), getClosestVehicle(), getGroundCoordsForEntity(), getWeaponHashFromInput(), giveTestWeapon(), loadModel() (+6 more)

### Community 6 - "Admin Menu Routing"
Cohesion: 0.19
Nodes (19): MZAdminGarageWizard.GetMenuId(), action(), execute(), input(), kickAction(), MZAdminMenu.Open(), openOnlinePlayers(), option() (+11 more)

### Community 7 - "Staff Management UI"
Cohesion: 0.33
Nodes (16): assignmentDetails(), assignRole(), bind(), createRole(), editRole(), input(), MZAdminStaffManagement.Register(), notify() (+8 more)

### Community 8 - "Door Management UI"
Cohesion: 0.32
Nodes (15): averageInteraction(), bind(), buildAccessPolicy(), configureDraft(), createGroup(), fetchGroups(), groupPolicyLabel(), MZAdminWorld.ShowDraft() (+7 more)

### Community 9 - "Ban Management UI"
Cohesion: 0.34
Nodes (14): MZAdminClient.StaffRequest(), bind(), cloneFilters(), errorMessage(), formatUnixUtc(), MZAdminBans.Configure(), MZAdminBans.Open(), MZAdminBans.PromptCreate() (+6 more)

### Community 10 - "Noclip Runtime"
Cohesion: 0.22
Nodes (9): applyNoClipState(), stopNoClip(), toggleNoClipAuthorized(), getNoClipEntity(), MZNoClip.stop(), MZNoClip.toggle(), notify(), restoreEntity() (+1 more)

### Community 11 - "Warning Management UI"
Cohesion: 0.30
Nodes (14): bind(), cloneFilters(), errorMessage(), formatUnixUtc(), MZAdminWarnings.Configure(), MZAdminWarnings.Open(), MZAdminWarnings.OpenForPlayer(), MZAdminWarnings.PromptIssue() (+6 more)

### Community 12 - "Wall Server Observability"
Cohesion: 0.33
Nodes (13): actorPayload(), audit(), citizenId(), filteredSnapshot(), MZAdminWall.BuildSnapshot(), MZAdminWall.IsEnabled(), MZAdminWall.Tick(), normalizeSource() (+5 more)

### Community 13 - "Client Server Adapter"
Cohesion: 0.36
Nodes (12): awaitCallback(), MZAdminClient.Authorize(), MZAdminClient.CreateManagedGarage(), MZAdminClient.GetMenuContext(), MZAdminClient.ListAdminLogs(), MZAdminClient.ListGarageOrganizations(), MZAdminClient.ListManagedGarages(), MZAdminClient.ListOnlinePlayers() (+4 more)

### Community 14 - "Security Alert UI"
Cohesion: 0.36
Nodes (10): bind(), detailMenuId(), evidenceMetadata(), incidentMetadata(), MZAdminSecurityAlerts.OpenList(), MZAdminSecurityAlerts.Register(), notify(), openDetails() (+2 more)

### Community 15 - "Player Action Orchestration"
Cohesion: 0.29
Nodes (10): auditTargetAction(), authorize(), authorizeTargetAction(), hierarchyDeniedMessage(), hierarchyRole(), MZAdminNoClip.IsEnabled(), notifyDenied(), resolveTargetHierarchy() (+2 more)

### Community 16 - "Wall Client Rendering"
Cohesion: 0.27
Nodes (7): cleanText(), cleanupWall(), MZAdminWallClient.SetState(), notify(), setting(), toggleWall(), vehicleLabel()

### Community 17 - "Whitelist UI"
Cohesion: 0.44
Nodes (9): binding(), decide(), formatUnixUtc(), MZAdminWhitelist.Register(), notify(), openStatus(), registerEntryMenu(), request() (+1 more)

### Community 18 - "Admin Logs UI"
Cohesion: 0.47
Nodes (8): bind(), cloneFilters(), displayDate(), hasFilters(), itemMetadata(), MZAdminLogs.Open(), requestFilters(), trim()

### Community 19 - "Spectate Client Runtime"
Cohesion: 0.36
Nodes (7): applyHiddenState(), notify(), restorePedState(), stopLocal(), updateTarget(), validCoords(), CreateThread()

## Knowledge Gaps
- **3 isolated node(s):** `Guard de hierarquia Staff`, `Diretório read-only de players online`, `Adaptação do domínio de advertências`
  These have ≤1 connection - possible missing edges or undocumented components.
- **1 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Are the 13 inferred relationships involving `MZAdminMenu.Open()` (e.g. with `MZAdminClient.GetMenuContext()` and `MZAdminBans.Configure()`) actually correct?**
  _`MZAdminMenu.Open()` has 13 INFERRED edges - model-reasoned connections that need verification._
- **Are the 7 inferred relationships involving `MZAdminSpectate.Start()` (e.g. with `MZAdminNoClip.IsEnabled()` and `MZAdminSecurity.Authorize()`) actually correct?**
  _`MZAdminSpectate.Start()` has 7 INFERRED edges - model-reasoned connections that need verification._
- **Are the 5 inferred relationships involving `MZAdminWall.BuildSnapshot()` (e.g. with `GetEntityCoords()` and `GetGameTimer()`) actually correct?**
  _`MZAdminWall.BuildSnapshot()` has 5 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Guard de hierarquia Staff`, `Diretório read-only de players online`, `Adaptação do domínio de advertências` to the rest of the system?**
  _3 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Documentation and Contracts` be split into smaller, more focused modules?**
  _Cohesion score 0.06312292358803986 - nodes in this community are weakly interconnected._
- **Should `Security and Moderation Adapters` be split into smaller, more focused modules?**
  _Cohesion score 0.12878787878787878 - nodes in this community are weakly interconnected._
- **Should `Spectate Server and Harness` be split into smaller, more focused modules?**
  _Cohesion score 0.13636363636363635 - nodes in this community are weakly interconnected._