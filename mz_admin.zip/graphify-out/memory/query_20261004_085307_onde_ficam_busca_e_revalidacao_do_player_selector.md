---
type: "query"
date: "2026-10-04T08:53:07.189540+00:00"
question: "Onde ficam busca e revalidacao do Player Selector administrativo?"
contributor: "graphify"
outcome: "useful"
source_nodes: ["MZAdminClient.SearchPlayers()", "MZAdminSecurity.ValidateTargetIdentity()"]
---

# Q: Onde ficam busca e revalidacao do Player Selector administrativo?

## Answer

mz_admin fornece MZAdminClient.SearchPlayers e o callback server searchPlayers; MZAdminSecurity.ValidateTargetIdentity rejeita source reutilizado antes das acoes.

## Outcome

- Signal: useful

## Source Nodes

- MZAdminClient.SearchPlayers()
- MZAdminSecurity.ValidateTargetIdentity()