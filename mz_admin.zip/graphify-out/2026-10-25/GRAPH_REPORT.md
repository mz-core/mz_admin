# Graph Report - mz_admin  (2026-10-25)

## Corpus Check
- 71 files · ~77,605 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 837 nodes · 1728 edges · 56 communities (55 shown, 1 thin omitted)
- Extraction: 84% EXTRACTED · 16% INFERRED · 0% AMBIGUOUS · INFERRED: 279 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `ae7b46cd`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- ui.lua
- Per-Context Visual Identity
- MZAdminUI.RegisterContext
- MZAdminSecurity.Authorize
- app.js
- MZAdminSpectate.Start
- router.lua
- garage_wizard.lua
- commands.lua
- client/warnings.lua
- mz_menu
- Contrato de segurança e menu do `mz_admin`
- MZAdminUI.InputDialog
- noclip.lua
- escapeHtml
- setTabletView
- post
- client/wall.lua
- MZAdminLogs.Open
- MZ Admin Unificado — Auditoria e Matriz de Cobertura
- staff_management.lua
- MZ Admin — NUI própria e contratos públicos
- Plano de adaptação do painel Staff QBCore
- Contrato dos logs administrativos
- Contrato de layout dashboard do `mz_menu`
- Checklist runtime do `mz_admin`
- Contrato do spectate administrativo
- Contrato do wall administrativo
- Implementação da integração BanGuard
- Prontidão da integração com BanGuard
- Q: Como o Player Selector se integra ao mz_menu?
- Q: Onde ficam busca e revalidacao do Player Selector administrativo?
- logs.lua
- renderTabletTabs
- Integração em resources MZ
- Contrato de tema por contexto do `mz_menu`
- Contrato de interação e movimento do contexto

## God Nodes (most connected - your core abstractions)
1. `MZAdminUI.ShowContext()` - 46 edges
2. `MZAdminUI.RegisterContext()` - 45 edges
3. `MZAdminUI.Notify()` - 23 edges
4. `MZAdminSecurity.Authorize()` - 22 edges
5. `MZAdminMenu.RegisterModules()` - 21 edges
6. `MZAdminRouter.Open()` - 21 edges
7. `escapeHtml()` - 20 edges
8. `MZAdminSpectate.Start()` - 19 edges
9. `GetGameTimer()` - 19 edges
10. `MZAdminUI.InputDialog()` - 18 edges

## Surprising Connections (you probably didn't know these)
- `Business Resource Ownership` --semantically_similar_to--> `Server-Side Security Boundary`  [INFERRED] [semantically similar]
  docs/INTEGRATION_NOTES.md → README.md
- `Menu Presentation Responsibility` --semantically_similar_to--> `mz_menu Visual Layer`  [INFERRED] [semantically similar]
  docs/INTEGRATION_NOTES.md → README.md
- `MZAdminMenu.RegisterModules()` --calls--> `MZAdminStaffManagement.GetMenuId()`  [INFERRED]
  mz_admin/client/menu.lua → mz_admin/client/staff_management.lua
- `MZAdminMenu.RegisterModules()` --calls--> `MZAdminWarnings.GetMenuId()`  [INFERRED]
  mz_admin/client/menu.lua → mz_admin/client/warnings.lua
- `MZAdminSpectate.Start()` --calls--> `MZAdminNoClip.IsEnabled()`  [INFERRED]
  mz_admin/server/spectate.lua → mz_admin/server/main.lua

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Context Visual Identity Flow** — readme_native_nui_backend, docs_context_theme_contract_context_visual_identity, docs_context_theme_contract_theme_inheritance_chain, web_index_context_panel [INFERRED 0.85]
- **Visual Layer Security Boundary** — readme_server_side_security_boundary, docs_context_theme_contract_visual_metadata_authorization_boundary, docs_integration_notes_business_resource_ownership, docs_integration_notes_menu_presentation_responsibility [INFERRED 0.95]

## Communities (56 total, 1 thin omitted)

### Community 0 - "ui.lua"
Cohesion: 0.07
Nodes (73): MZAdminPlayerSelector.Select(), actualMovementEnabled(), alertReady(), applyMovementInput(), awaitNui(), beginNuiDialog(), cfg(), chat() (+65 more)

### Community 1 - "Per-Context Visual Identity"
Cohesion: 0.11
Nodes (18): Per-Context Visual Identity, Theme Inheritance Chain, Theme Payload Validation, Visual Metadata Authorization Boundary, Business Resource Ownership, Embedded Asset Strategy, Menu Presentation Responsibility, Combat Input Suppression (+10 more)

### Community 2 - "MZAdminUI.RegisterContext"
Cohesion: 0.06
Nodes (65): MZAdminGarageWizard.GetMenuId(), action(), execute(), input(), kickAction(), MZAdminMenu.GetNavigationTabs(), MZAdminMenu.Open(), MZAdminMenu.RegisterModules() (+57 more)

### Community 3 - "MZAdminSecurity.Authorize"
Cohesion: 0.09
Nodes (39): auditResult(), banGuardCall(), MZAdminBansServer.Create(), MZAdminBansServer.Get(), MZAdminBansServer.List(), MZAdminBansServer.Revoke(), response(), auditTargetAction() (+31 more)

### Community 4 - "app.js"
Cohesion: 0.03
Nodes (54): app, backBtn, brandEl, closeBtn, contextPanel, dashboardMeta, dialogEl, dialogOverlay (+46 more)

### Community 5 - "MZAdminSpectate.Start"
Cohesion: 0.06
Nodes (55): getClosestVehicle(), getGroundCoordsForEntity(), applyHiddenState(), notify(), restorePedState(), stopLocal(), updateTarget(), validCoords() (+47 more)

### Community 6 - "router.lua"
Cohesion: 0.12
Nodes (42): awaitCallback(), banPlayer(), btn(), buildActionRows(), buildCharactersRows(), buildHistoryRows(), buildInfoRows(), buildNavigationTabs() (+34 more)

### Community 7 - "garage_wizard.lua"
Cohesion: 0.13
Nodes (39): awaitCallback(), MZAdminClient.Authorize(), MZAdminClient.CreateManagedGarage(), MZAdminClient.GetMenuContext(), MZAdminClient.ListAdminLogs(), MZAdminClient.ListGarageOrganizations(), MZAdminClient.ListManagedGarages(), MZAdminClient.ListOnlinePlayers() (+31 more)

### Community 8 - "commands.lua"
Cohesion: 0.10
Nodes (27): applyMaxPerformance(), applyRandomVisualTuning(), authorize(), blockNativeWeaponCommand(), deleteVehicle(), fullRandomTune(), getWeaponHashFromInput(), giveTestWeapon() (+19 more)

### Community 9 - "client/warnings.lua"
Cohesion: 0.15
Nodes (30): MZAdminClient.StaffRequest(), bind(), cloneFilters(), errorMessage(), formatUnixUtc(), MZAdminBans.Configure(), MZAdminBans.Open(), MZAdminBans.PromptCreate() (+22 more)

### Community 10 - "mz_menu"
Cohesion: 0.12
Nodes (16): Alert / Confirm, Backend, Exports client-side, Exports server-side, Ideia, Input, Layout dashboard (0.4.0-test), Layout v0 convertido (+8 more)

### Community 11 - "Contrato de segurança e menu do `mz_admin`"
Cohesion: 0.11
Nodes (18): Autoridade, Ação local, Ação sobre outro player, Banimentos, Compatibilidade, Contrato de segurança e menu do `mz_admin`, Criacao de garagens, Diretório de players (+10 more)

### Community 12 - "MZAdminUI.InputDialog"
Cohesion: 0.30
Nodes (16): MZAdminUI.InputDialog(), averageInteraction(), bind(), buildAccessPolicy(), configureDraft(), createGroup(), fetchGroups(), groupPolicyLabel() (+8 more)

### Community 13 - "noclip.lua"
Cohesion: 0.21
Nodes (11): applyNoClipState(), stopNoClip(), toggleNoClipAuthorized(), getNoClipEntity(), MZNoClip.stop(), MZNoClip.toggle(), notify(), restoreEntity() (+3 more)

### Community 14 - "escapeHtml"
Cohesion: 0.16
Nodes (23): applySearchFilter(), escapeHtml(), notify(), openContext(), openInputDialog(), openPlayerSelector(), openTabletModal(), renderDashboardMeta() (+15 more)

### Community 15 - "setTabletView"
Cohesion: 0.29
Nodes (11): bindModalRows(), bindTabletCards(), bindTabletRows(), postLocked(), renderFlightHome(), renderTabletFilters(), setTabletContext(), setTabletMode() (+3 more)

### Community 16 - "post"
Cohesion: 0.19
Nodes (13): bindPlayerSelectorResults(), cancelPlayerSelector(), closeAll(), closeDialogAsCancel(), closeTablet(), closeTabletModal(), cycleTabletTab(), getAlertVariant() (+5 more)

### Community 17 - "client/wall.lua"
Cohesion: 0.27
Nodes (7): cleanText(), cleanupWall(), MZAdminWallClient.SetState(), notify(), setting(), toggleWall(), vehicleLabel()

### Community 18 - "MZAdminLogs.Open"
Cohesion: 0.47
Nodes (8): bind(), cloneFilters(), displayDate(), hasFilters(), itemMetadata(), MZAdminLogs.Open(), requestFilters(), trim()

### Community 19 - "MZ Admin Unificado — Auditoria e Matriz de Cobertura"
Cohesion: 0.20
Nodes (9): ADMIN (árvore canônica do `/admin`), Bloqueios / pendências identificadas, Contratos de identidade (mz_core, SOMENTE LEITURA — autoridade canônica), Estado dos repos (dirty, preservado — sem commits/checkout/reset), JOGADORES (lista + modal), MAIN (Minha sessão + ferramentas rápidas), Matriz /admin → função → capability → owner/callback → novo destino → estado, MZ Admin Unificado — Auditoria e Matriz de Cobertura (+1 more)

### Community 20 - "staff_management.lua"
Cohesion: 0.30
Nodes (17): assignmentDetails(), assignRole(), bind(), createRole(), editRole(), input(), MZAdminStaffManagement.GetMenuId(), MZAdminStaffManagement.Register() (+9 more)

### Community 21 - "MZ Admin — NUI própria e contratos públicos"
Cohesion: 0.22
Nodes (8): Direção visual, Entrada, Eventos client, Exports client, Fluxo, Homologação FiveM pendente, MZ Admin — NUI própria e contratos públicos, Ownership

### Community 22 - "Plano de adaptação do painel Staff QBCore"
Cohesion: 0.22
Nodes (8): Adaptação concluída: advertências, Lote de garagens aplicado, Matriz, Plano de adaptação do painel Staff QBCore, Primeiro lote aplicado, Princípios da adaptação, Próxima ordem, Referência analisada

### Community 23 - "Contrato dos logs administrativos"
Cohesion: 0.25
Nodes (7): Autorização, Compatibilidade do `mz_org`, Contrato dos logs administrativos, DTO, Escopo, Filtros, Responsabilidades

### Community 24 - "Contrato de layout dashboard do `mz_menu`"
Cohesion: 0.25
Nodes (7): Busca, Campos de contexto, Campos de opcao, Compatibilidade, Contrato de layout dashboard do `mz_menu`, Objetivo, Seguranca

### Community 25 - "Checklist runtime do `mz_admin`"
Cohesion: 0.25
Nodes (7): Advertências (`mz_warns`), Checklist runtime do `mz_admin`, Evidência, Interface e regressão, Negativos obrigatórios, Positivos por permissão, Preparação

### Community 26 - "Contrato do spectate administrativo"
Cohesion: 0.25
Nodes (7): Auditoria, Autoridade, Contrato do spectate administrativo, Estado local, Estado oficial, Lifecycle, Limites

### Community 27 - "Contrato do wall administrativo"
Cohesion: 0.25
Nodes (7): Auditoria, Autoridade, Configuração segura, Contrato do wall administrativo, Dados, Estado e revalidação, Fora do escopo

### Community 29 - "Implementação da integração BanGuard"
Cohesion: 0.29
Nodes (6): Comandos estáticos, Entrega local, Implementação da integração BanGuard, Runtime pendente, Segurança, Validação estática executada

### Community 30 - "Prontidão da integração com BanGuard"
Cohesion: 0.33
Nodes (5): Ações proibidas, Bloqueio runtime real, Estado atual, Integração aplicada, Prontidão da integração com BanGuard

### Community 31 - "Q: Como o Player Selector se integra ao mz_menu?"
Cohesion: 0.40
Nodes (4): Answer, Outcome, Q: Como o Player Selector se integra ao mz_menu?, Source Nodes

### Community 32 - "Q: Onde ficam busca e revalidacao do Player Selector administrativo?"
Cohesion: 0.40
Nodes (4): Answer, Outcome, Q: Onde ficam busca e revalidacao do Player Selector administrativo?, Source Nodes

### Community 48 - "renderTabletTabs"
Cohesion: 0.32
Nodes (8): clearTabletWorkspace(), hideTabletTooltip(), openTablet(), renderTabletNav(), renderTabletTabs(), setTabletExpanded(), showTabletTooltip(), suspendTablet()

### Community 53 - "Integração em resources MZ"
Cohesion: 0.20
Nodes (9): Integração em resources MZ, Interacao e movimento do contexto, NUI própria, Não fazer, Ordem no server.cfg, Padrão recomendado, Sobre virar uma lib maior, Versão 0.3.0 - NUI própria estilo v0 (+1 more)

### Community 55 - "Contrato de tema por contexto do `mz_menu`"
Cohesion: 0.22
Nodes (8): Ciclo de vida, Compatibilidade, Contrato de tema por contexto do `mz_menu`, Escopo, Limite de responsabilidade, Payload, Resolucao e heranca, Teste manual

### Community 56 - "Contrato de interação e movimento do contexto"
Cohesion: 0.22
Nodes (8): Configuração, Contrato de interação e movimento do contexto, Exports de movimento, Objetivo, Ownership dos atalhos, Posicionamento de garagens, Regras, Teste runtime

## Knowledge Gaps
- **174 isolated node(s):** `app`, `contextPanel`, `menuTitle`, `brandEl`, `menuSubtitle` (+169 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **1 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `GetGameTimer()` connect `commands.lua` to `ui.lua`, `MZAdminUI.RegisterContext`, `MZAdminSecurity.Authorize`, `MZAdminSpectate.Start`, `router.lua`, `MZAdminUI.InputDialog`?**
  _High betweenness centrality (0.121) - this node is a cross-community bridge._
- **Why does `MZAdminUI.ShowContext()` connect `ui.lua` to `MZAdminUI.RegisterContext`, `garage_wizard.lua`, `commands.lua`, `client/warnings.lua`, `MZAdminUI.InputDialog`, `MZAdminLogs.Open`, `staff_management.lua`?**
  _High betweenness centrality (0.058) - this node is a cross-community bridge._
- **Why does `MZAdminUI.Notify()` connect `ui.lua` to `MZAdminUI.RegisterContext`, `MZAdminSpectate.Start`, `router.lua`, `garage_wizard.lua`, `commands.lua`, `client/warnings.lua`, `MZAdminUI.InputDialog`, `client/wall.lua`, `staff_management.lua`?**
  _High betweenness centrality (0.056) - this node is a cross-community bridge._
- **Are the 32 inferred relationships involving `MZAdminUI.ShowContext()` (e.g. with `MZAdminLogs.Open()` and `MZAdminBans.Open()`) actually correct?**
  _`MZAdminUI.ShowContext()` has 32 INFERRED edges - model-reasoned connections that need verification._
- **Are the 41 inferred relationships involving `MZAdminUI.RegisterContext()` (e.g. with `MZAdminLogs.Open()` and `MZAdminBans.Open()`) actually correct?**
  _`MZAdminUI.RegisterContext()` has 41 INFERRED edges - model-reasoned connections that need verification._
- **Are the 15 inferred relationships involving `MZAdminUI.Notify()` (e.g. with `notifyDenied()` and `notify()`) actually correct?**
  _`MZAdminUI.Notify()` has 15 INFERRED edges - model-reasoned connections that need verification._
- **Are the 15 inferred relationships involving `MZAdminSecurity.Authorize()` (e.g. with `MZAdminBansServer.Create()` and `MZAdminBansServer.Get()`) actually correct?**
  _`MZAdminSecurity.Authorize()` has 15 INFERRED edges - model-reasoned connections that need verification._